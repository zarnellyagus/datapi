import { Component, OnInit } from '@angular/core';
import { MenuService } from '../../../core/services/menu.service';
import { AuthService } from '../../../core/services/auth.service';
import { Menu } from '../../models/menu.model';

@Component({
  selector: 'app-sidebar',
  standalone:false,
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
  menus: Menu[] = [];
  staticMenus = [
    { objectId: 'dashboard', objectName: 'Dashboard' },
    { objectId: 'consolidate-policy', objectName: 'Consolidate Policy' }
  ];

  constructor(
    private menuService: MenuService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    const user = this.authService.getCurrentUser();
    if (user) {
      this.menuService.getUserMenus(user.userId, user.companyId).subscribe(
        menus => this.menus = [...this.staticMenus, ...menus]
      );
    }
  }
}

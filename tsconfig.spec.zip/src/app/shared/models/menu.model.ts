export interface Menu {
  objectId: string;
  objectName: string;
}

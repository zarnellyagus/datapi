export interface User {
  userId: string;
  companyId: string;
  userName?: string;
}

export interface LoginRequest {
  userId: string;
  companyId: string;
}

export interface LoginResponse {
  userId: string;
  companyId: string;
  token: string;
}

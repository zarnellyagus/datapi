import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { forkJoin } from 'rxjs';
import { PolicyService } from '../../../core/services/policy.service';
import { PolicyInfo, EPolicy, PolicySummary } from '../../../shared/models/policy.model';

@Component({
  selector: 'app-policy-detail',
  standalone:false,
  templateUrl: './policy-detail.component.html',
  styleUrls: ['./policy-detail.component.scss']
})
export class PolicyDetailComponent implements OnInit {
  policyId: string = '';
  activeTab = 'info';
  
  policyInfo: PolicyInfo | null = null;
  ePolicies: EPolicy[] = [];
  policySummary: PolicySummary | null = null;

  constructor(
    private route: ActivatedRoute,
    private policyService: PolicyService
  ) {}

  ngOnInit(): void {
    this.policyId = this.route.snapshot.paramMap.get('id') || '';
    this.loadAllData();
  }

  loadAllData(): void {
    forkJoin({
      info: this.policyService.getPolicyInfo(this.policyId),
      epolicy: this.policyService.getEPolicy(this.policyId),
      summary: this.policyService.getPolicySummary(this.policyId)
    }).subscribe(result => {
      this.policyInfo = result.info;
      this.ePolicies = result.epolicy;
      this.policySummary = result.summary;
    });
  }

  setActiveTab(tab: string): void {
    this.activeTab = tab;
  }
}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PolicyService } from '../../../core/services/policy.service';
import { ConsolidatePolicy } from '../../../shared/models/policy.model';

@Component({
  selector: 'app-policy-list',
  standalone:false,
  templateUrl: './policy-list.component.html',
  styleUrls: ['./policy-list.component.scss']
})
export class PolicyListComponent implements OnInit {
  policies: ConsolidatePolicy[] = [];
  totalRecords = 0;
  currentPage = 1;
  pageSize = 10;
  totalPages = 0;
  
  searchPolicyId = '';
  searchAppNo = '';
  pageSizes = [10, 25, 50, 100];

  constructor(
    private policyService: PolicyService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadPolicies();
  }

  loadPolicies(): void {
    this.policyService.getPolicies(
      this.searchPolicyId || undefined,
      this.searchAppNo || undefined,
      this.currentPage,
      this.pageSize
    ).subscribe(response => {
      this.policies = response.data;
      this.totalRecords = response.totalRecords;
      this.totalPages = response.totalPages;
    });
  }

  onSearch(): void {
    this.currentPage = 1;
    this.loadPolicies();
  }

  onPageChange(page: number): void {
    this.currentPage = page;
    this.loadPolicies();
  }

  onPageSizeChange(): void {
    this.currentPage = 1;
    this.loadPolicies();
  }

  viewDetail(policyId: string): void {
    this.router.navigate(['/consolidate-policy/detail', policyId]);
  }

  get pages(): number[] {
    return Array.from({ length: this.totalPages }, (_, i) => i + 1);
  }
}

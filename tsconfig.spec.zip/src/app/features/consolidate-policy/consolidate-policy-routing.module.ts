// src/app/features/consolidate-policy/consolidate-policy-routing.module.ts
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PolicyListComponent } from './policy-list/policy-list.component';
import { PolicyDetailComponent } from './policy-detail/policy-detail.component';

const routes: Routes = [
  {
    path: '',
    component: PolicyListComponent
  },
  {
    path: 'detail/:id',
    component: PolicyDetailComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ConsolidatePolicyRoutingModule { }

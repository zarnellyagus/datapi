// src/app/features/consolidate-policy/consolidate-policy.module.ts
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ConsolidatePolicyRoutingModule } from './consolidate-policy-routing.module';
import { PolicyListComponent } from './policy-list/policy-list.component';
import { PolicyDetailComponent } from './policy-detail/policy-detail.component';

@NgModule({
  declarations: [
    PolicyListComponent,
    PolicyDetailComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ConsolidatePolicyRoutingModule
  ]
})
export class ConsolidatePolicyModule { }

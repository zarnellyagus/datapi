// src/app/features/auth/auth.module.ts
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms'; // PENTING!
import { AuthRoutingModule } from './auth-routing.module';
import { LoginComponent } from './login/login.component';
import { AuthCallbackComponent } from './auth-callback/auth-callback.component';

@NgModule({
  declarations: [
    LoginComponent,
    AuthCallbackComponent
  ],
  imports: [
    CommonModule,
    FormsModule,        // HARUS ADA INI!
    AuthRoutingModule
  ]
})
export class AuthModule { }

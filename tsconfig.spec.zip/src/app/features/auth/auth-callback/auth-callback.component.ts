// src/app/features/auth/auth-callback/auth-callback.component.ts
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-auth-callback',
  standalone:false,
  templateUrl: './auth-callback.component.html',
  styleUrls: ['./auth-callback.component.scss']
})
export class AuthCallbackComponent implements OnInit {
  message: string = 'Processing authentication...';
  isError: boolean = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      const token = params['token'];
      const userId = params['userId'];
      const companyId = params['companyId'];
      const error = params['error'];

      if (error) {
        this.isError = true;
        this.message = 'Authentication failed. Please try again.';
        setTimeout(() => {
          this.router.navigate(['/login']);
        }, 3000);
        return;
      }

      if (token && userId && companyId) {
        localStorage.setItem('token', token);
        localStorage.setItem('currentUser', JSON.stringify({ userId, companyId }));
        
        this.message = 'Login successful! Redirecting...';
        setTimeout(() => {
          this.router.navigate(['/dashboard']);
        }, 1000);
      } else {
        this.isError = true;
        this.message = 'Authentication failed. Missing data.';
        setTimeout(() => {
          this.router.navigate(['/login']);
        }, 3000);
      }
    });
  }
}

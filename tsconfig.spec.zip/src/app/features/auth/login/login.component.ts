// src/app/features/auth/login/login.component.ts
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { LoginRequest } from '../../../shared/models/user.model';

@Component({
  selector: 'app-login',
  standalone:false,
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginRequest: LoginRequest = {
    userId: '',
    companyId: 'CP'
  };
  
  errorMessage: string = '';
  isLoading: boolean = false;
  useSso: boolean = true;

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    if (this.authService.isAuthenticated()) {
      this.router.navigate(['/dashboard']);
    }
  }

  loginWithSSO(): void {
    this.isLoading = true;
    // Redirect ke backend SAML endpoint
    window.location.href = 'https://istaruat.id.sunlife:4491/api/auth/login';
  }

  loginDirect(): void {
    this.errorMessage = '';
    
    if (!this.loginRequest.userId) {
      this.errorMessage = 'User ID is required';
      return;
    }
    
    if (!this.loginRequest.companyId) {
      this.errorMessage = 'Company ID is required';
      return;
    }
    
    this.isLoading = true;
    
    this.authService.login(this.loginRequest).subscribe({
      next: (response) => {
        console.log('Login successful', response);
        this.router.navigate(['/dashboard']);
      },
      error: (error) => {
        console.error('Login failed', error);
        this.errorMessage = error.message || 'Login failed. Please try again.';
        this.isLoading = false;
      },
      complete: () => {
        this.isLoading = false;
      }
    });
  }

  toggleLoginMode(): void {
    this.useSso = !this.useSso;
    this.errorMessage = '';
  }
}

// src/app/features/dashboard/dashboard.component.ts
import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../core/services/auth.service';
import { MenuService } from '../../core/services/menu.service';
import { User } from '../../shared/models/user.model';
import { Menu } from '../../shared/models/menu.model';

@Component({
  selector: 'app-dashboard',
  standalone:false,
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  currentUser: User | null = null;
  menus: Menu[] = [];
  isLoading: boolean = true;
  
  // Dashboard statistics
  stats = {
    totalPolicies: 0,
    activePolicies: 0,
    pendingPolicies: 0,
    completedPolicies: 0
  };

  // Recent activities
  recentActivities: any[] = [];

  constructor(
    private authService: AuthService,
    private menuService: MenuService
  ) {}

  ngOnInit(): void {
    this.loadUserData();
    this.loadDashboardData();
  }

  loadUserData(): void {
    this.currentUser = this.authService.getCurrentUser();
    
    if (this.currentUser) {
      this.menuService.getUserMenus(this.currentUser.userId, this.currentUser.companyId)
        .subscribe({
          next: (menus) => {
            this.menus = menus;
          },
          error: (error) => {
            console.error('Error loading menus:', error);
          }
        });
    }
  }

  loadDashboardData(): void {
    this.isLoading = true;
    
    // Simulate loading dashboard statistics
    // TODO: Replace with actual API calls
    setTimeout(() => {
      this.stats = {
        totalPolicies: 1250,
        activePolicies: 980,
        pendingPolicies: 145,
        completedPolicies: 125
      };

      this.recentActivities = [
        {
          id: 1,
          type: 'Policy Created',
          description: 'New policy POL-2025-001 created',
          timestamp: new Date('2025-10-12T10:30:00'),
          icon: 'bi-file-earmark-plus',
          color: 'success'
        },
        {
          id: 2,
          type: 'Policy Updated',
          description: 'Policy POL-2025-002 status updated',
          timestamp: new Date('2025-10-12T09:15:00'),
          icon: 'bi-pencil-square',
          color: 'info'
        },
        {
          id: 3,
          type: 'Policy Approved',
          description: 'Policy POL-2025-003 approved',
          timestamp: new Date('2025-10-11T16:45:00'),
          icon: 'bi-check-circle',
          color: 'primary'
        },
        {
          id: 4,
          type: 'Policy Rejected',
          description: 'Policy POL-2025-004 needs revision',
          timestamp: new Date('2025-10-11T14:20:00'),
          icon: 'bi-x-circle',
          color: 'danger'
        },
        {
          id: 5,
          type: 'Report Generated',
          description: 'Monthly report generated',
          timestamp: new Date('2025-10-11T11:00:00'),
          icon: 'bi-file-earmark-text',
          color: 'warning'
        }
      ];

      this.isLoading = false;
    }, 1000);
  }

  getGreeting(): string {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good Morning';
    if (hour < 18) return 'Good Afternoon';
    return 'Good Evening';
  }

  getRelativeTime(date: Date): string {
    const now = new Date();
    const diff = now.getTime() - new Date(date).getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (minutes < 1) return 'just now';
    if (minutes < 60) return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
    if (hours < 24) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    return `${days} day${days > 1 ? 's' : ''} ago`;
  }
}

import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { PolicyListResponse, PolicyInfo, EPolicy, PolicySummary } from '../../shared/models/policy.model'
@Injectable({
  providedIn: 'root'
})
export class PolicyService {
  private apiUrl = 'https://istaruat.id.sunlife:4491/api/consolidatepolicy';

  constructor(private http: HttpClient) {}

  getPolicies(policyId?: string, appNo?: string, page: number = 1, pageSize: number = 10): Observable<PolicyListResponse> {
    let params = new HttpParams()
      .set('page', page.toString())
      .set('pageSize', pageSize.toString());

    if (policyId) params = params.set('policyId', policyId);
    if (appNo) params = params.set('appNo', appNo);

    return this.http.get<PolicyListResponse>(this.apiUrl, { params });
  }

  getPolicyInfo(policyId: string): Observable<PolicyInfo> {
    return this.http.get<PolicyInfo>(`${this.apiUrl}/${policyId}/info`);
  }

  getEPolicy(policyId: string): Observable<EPolicy[]> {
    return this.http.get<EPolicy[]>(`${this.apiUrl}/${policyId}/epolicy`);
  }

  getPolicySummary(policyId: string): Observable<PolicySummary> {
    return this.http.get<PolicySummary>(`${this.apiUrl}/${policyId}/summary`);
  }
}

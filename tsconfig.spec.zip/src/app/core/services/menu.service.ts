import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Menu } from '../../shared/models/menu.model';

@Injectable({
  providedIn: 'root'
})
export class MenuService {
  private apiUrl = 'https://istaruat.id.sunlife:4491/api/menu';

  constructor(private http: HttpClient) {}

  getUserMenus(userId: string, companyId: string): Observable<Menu[]> {
    return this.http.get<Menu[]>(`${this.apiUrl}?userId=${userId}&companyId=${companyId}`);
  }
}

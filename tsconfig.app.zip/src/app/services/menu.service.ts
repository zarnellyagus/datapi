import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface MenuItem {
  objectId: string;
  objectName: string;
}

@Injectable({
  providedIn: 'root'
})
export class MenuService {
  private apiUrl = 'http://localhost:7076/api/menu';

  constructor(private http: HttpClient) {}

  getUserMenu(userId: string, companyId: string): Observable<MenuItem[]> {
    const params = new HttpParams()
      .set('userId', userId)
      .set('companyId', companyId);
    
    return this.http.get<MenuItem[]>(`${this.apiUrl}/user-menu`, { params });
  }
}

import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface PagedResult<T> {
  data: T[];
  totalCount: number;
  pageNumber: number;
  pageSize: number;
  totalPages: number;
}

export interface ConsolidatePolicy {
  companyID: string;
  policyID: string;
  appNo: string;
  ownerName: string;
  issuedDate: Date;
}

export interface PolicyDetail {
  spajNo: string;
  policyNo: string;
  clientID: string;
  ownerName: string;
  insuredName: string;
  planName: string;
  issuedDate: Date;
  agentId: string;
  branchName: string;
  email: string;
  tlpNum: string;
  ttp: string;
  receiveDate: string;
}

export interface EPolicyInfo {
  ePolSource: string;
  statusDate: Date;
  status: string;
}

export interface PolicySummary {
  polSumPolicyID: string;
  polSumPickUpDate: Date;
  polSumStatusDate: Date;
  polSumStatus: string;
  polSumReceiver: string;
  polSumRelation: string;
  polSumReturn: string;
  polSumResiNo: string;
  polSumCourier: string;
}

@Injectable({
  providedIn: 'root'
})
export class PolicyService {
  private apiUrl = 'http://localhost:7076/api/policy';

  constructor(private http: HttpClient) {}

  getConsolidatePolicies(
    policyId: string | null,
    appNo: string | null,
    pageNumber: number,
    pageSize: number
  ): Observable<PagedResult<ConsolidatePolicy>> {
    let params = new HttpParams()
      .set('pageNumber', pageNumber.toString())
      .set('pageSize', pageSize.toString());
    
    if (policyId) params = params.set('policyId', policyId);
    if (appNo) params = params.set('appNo', appNo);

    return this.http.get<PagedResult<ConsolidatePolicy>>(
      `${this.apiUrl}/consolidate`, 
      { params }
    );
  }

  getPolicyDetail(policyId: string): Observable<PolicyDetail> {
    return this.http.get<PolicyDetail>(`${this.apiUrl}/detail/${policyId}`);
  }

  getEPolicyInfo(policyId: string): Observable<EPolicyInfo[]> {
    return this.http.get<EPolicyInfo[]>(`${this.apiUrl}/epolicy-info/${policyId}`);
  }

  getPolicySummary(policyId: string): Observable<PolicySummary[]> {
    return this.http.get<PolicySummary[]>(`${this.apiUrl}/summary/${policyId}`);
  }
}

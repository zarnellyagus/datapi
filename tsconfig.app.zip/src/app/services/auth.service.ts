import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Router } from '@angular/router';

export interface LoginRequest {
  username: string;
  password: string;
}

export interface LoginResponse {
  token: string;
  username: string;
  userId: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = 'http://localhost:7076/api/auth';
  private tokenSubject = new BehaviorSubject<string | null>(this.getToken());
  public token$ = this.tokenSubject.asObservable();

  constructor(
    private http: HttpClient,
    private router: Router
  ) {}

  /**
   * Traditional login with username/password
   */
  login(credentials: LoginRequest): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.apiUrl}/login`, credentials)
      .pipe(
        tap(response => {
          this.saveTokenData(response);
        })
      );
  }

  /**
   * SSO Login - Redirect to Microsoft Entra ID
   * This method redirects the browser to backend SSO endpoint
   */
  loginWithSSO(): void {
    const returnUrl = encodeURIComponent('/dashboard');
    window.location.href = `${this.apiUrl}/sso-login?returnUrl=${returnUrl}`;
  }

  /**
   * Direct SSO Login without return URL
   */
  directSSOLogin(): void {
    window.location.href = `${this.apiUrl}/direct-sso`;
  }

  /**
   * Handle SSO callback - Extract token from URL parameters
   * Called in dashboard or callback component after SSO redirect
   */
  handleSSOCallback(): boolean {
    const urlParams = new URLSearchParams(window.location.search);
    const token = urlParams.get('token');
    const username = urlParams.get('username');
    const userId = urlParams.get('userId');
    const error = urlParams.get('error');

    if (error) {
      console.error('SSO Error:', error);
      return false;
    }

    if (token && username && userId) {
      this.saveTokenData({
        token: token,
        username: username,
        userId: userId
      });

      // Clear URL parameters to clean up the URL
      window.history.replaceState({}, document.title, window.location.pathname);
      
      return true;
    }

    return false;
  }

  /**
   * Save token data to localStorage
   */
  private saveTokenData(response: LoginResponse): void {
    localStorage.setItem('token', response.token);
    localStorage.setItem('userId', response.userId);
    localStorage.setItem('username', response.username);
    this.tokenSubject.next(response.token);
  }

  /**
   * Logout - Clear session and redirect to login
   */
  logout(): void {
    // Call backend logout endpoint
    this.http.post(`${this.apiUrl}/logout`, {}).subscribe({
      next: () => {
        this.clearTokenData();
        this.router.navigate(['/login']);
      },
      error: () => {
        // Even if API call fails, clear local data
        this.clearTokenData();
        this.router.navigate(['/login']);
      }
    });
  }

  /**
   * Clear token data from localStorage
   */
  private clearTokenData(): void {
    localStorage.removeItem('token');
    localStorage.removeItem('userId');
    localStorage.removeItem('username');
    this.tokenSubject.next(null);
  }

  /**
   * Get stored token
   */
  getToken(): string | null {
    return localStorage.getItem('token');
  }

  /**
   * Get stored user ID
   */
  getUserId(): string | null {
    return localStorage.getItem('userId');
  }

  /**
   * Get stored username
   */
  getUsername(): string | null {
    return localStorage.getItem('username');
  }

  /**
   * Check if user is authenticated
   * Validates token expiration
   */
  isAuthenticated(): boolean {
    const token = this.getToken();
    if (!token) return false;
    
    // Check if token is expired
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      const expiry = payload.exp * 1000;
      const isValid = Date.now() < expiry;
      
      if (!isValid) {
        // Token expired, clear data
        this.clearTokenData();
      }
      
      return isValid;
    } catch (error) {
      console.error('Error validating token:', error);
      this.clearTokenData();
      return false;
    }
  }

  /**
   * Get current user info from token
   */
  getCurrentUser(): { username: string; userId: string; email?: string } | null {
    const token = this.getToken();
    if (!token) return null;

    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return {
        username: payload.username || payload.sub,
        userId: payload.sub,
        email: payload.email
      };
    } catch (error) {
      console.error('Error parsing token:', error);
      return null;
    }
  }
}

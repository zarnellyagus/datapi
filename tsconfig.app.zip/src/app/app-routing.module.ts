import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ConsolidatePolicyComponent } from './components/consolidate-policy/consolidate-policy.component';
import { PolicyDetailComponent } from './components/policy-detail/policy-detail.component';
import { SsoLoginComponent } from './components/sso-login/sso-login.component';
import { AuthGuard } from './guards/auth.guard';

const routes: Routes = [
  { path: '', redirectTo: '/sso-login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'sso-login', component: SsoLoginComponent },
  { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard] },
  { path: 'consolidate-policy', component: ConsolidatePolicyComponent, canActivate: [AuthGuard] },
  { path: 'policy-detail/:id', component: PolicyDetailComponent, canActivate: [AuthGuard] },
  { path: '**', redirectTo: '/sso-login' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

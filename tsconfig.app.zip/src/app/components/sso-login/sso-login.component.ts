import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-sso-login',
  standalone:false,
  templateUrl: './sso-login.component.html',
  styleUrls: ['./sso-login.component.scss']
})
export class SsoLoginComponent implements OnInit {
  errorMessage = '';

  constructor(
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    // Check if already authenticated
    if (this.authService.isAuthenticated()) {
      this.router.navigate(['/dashboard']);
      return;
    }

    // Check for SSO error
    const error = this.route.snapshot.queryParams['error'];
    if (error) {
      this.errorMessage = this.getErrorMessage(error);
      setTimeout(() => {
        this.router.navigate(['/login'], { 
          queryParams: { traditional: 'true', error: error } 
        });
      }, 3000);
      return;
    }

    // Direct redirect to SSO
    this.authService.loginWithSSO();
  }

  private getErrorMessage(errorCode: string): string {
    const errorMessages: { [key: string]: string } = {
      'authentication_failed': 'SSO authentication failed.',
      'no_user_data': 'Unable to retrieve user information.',
      'callback_error': 'An error occurred during SSO login.'
    };

    return errorMessages[errorCode] || 'An unknown error occurred.';
  }
}

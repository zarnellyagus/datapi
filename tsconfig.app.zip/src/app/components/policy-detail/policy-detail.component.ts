import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PolicyService, PolicyDetail, EPolicyInfo, PolicySummary } from '../../services/policy.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-policy-detail',
  standalone:false,
  templateUrl: './policy-detail.component.html',
  styleUrls: ['./policy-detail.component.scss']
})
export class PolicyDetailComponent implements OnInit {
  policyId = '';
  policyDetail: PolicyDetail | null = null;
  ePolicyInfo: EPolicyInfo[] = [];
  policySummary: PolicySummary[] = [];
  activeTab = 'policy';
  isLoading = false;
  username = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private policyService: PolicyService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.username = this.authService.getUsername() || '';
    this.policyId = this.route.snapshot.paramMap.get('id') || '';
    
    if (this.policyId) {
      this.loadPolicyDetail();
    }
  }

  loadPolicyDetail(): void {
    this.isLoading = true;
    
    this.policyService.getPolicyDetail(this.policyId).subscribe({
      next: (detail) => {
        this.policyDetail = detail;
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Error loading policy detail:', err);
        this.isLoading = false;
      }
    });

    this.policyService.getEPolicyInfo(this.policyId).subscribe({
      next: (info) => {
        this.ePolicyInfo = info;
      },
      error: (err) => console.error('Error loading e-policy info:', err)
    });

    this.policyService.getPolicySummary(this.policyId).subscribe({
      next: (summary) => {
        this.policySummary = summary;
      },
      error: (err) => console.error('Error loading policy summary:', err)
    });
  }

  goBack(): void {
    this.router.navigate(['/consolidate-policy']);
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}

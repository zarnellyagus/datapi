import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MenuService, MenuItem } from '../../services/menu.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-dashboard',
  standalone:false,
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  menus: MenuItem[] = [];
  username: string = '';
  isLoadingMenu = false;

  constructor(
    private menuService: MenuService,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    // Handle SSO callback if token is in URL
    const ssoSuccess = this.authService.handleSSOCallback();
    
    if (ssoSuccess) {
      console.log('SSO login successful');
    }

    // Check if user is authenticated
    if (!this.authService.isAuthenticated()) {
      this.router.navigate(['/login']);
      return;
    }

    const userId = this.authService.getUserId();
    this.username = this.authService.getUsername() || '';
    
    if (userId) {
      this.isLoadingMenu = true;
      this.menuService.getUserMenu(userId, 'CP').subscribe({
        next: (menus) => {
          this.menus = menus;
          this.isLoadingMenu = false;
        },
        error: (err) => {
          console.error('Error loading menu:', err);
          this.isLoadingMenu = false;
        }
      });
    }
  }

  logout(): void {
    this.authService.logout();
  }
}

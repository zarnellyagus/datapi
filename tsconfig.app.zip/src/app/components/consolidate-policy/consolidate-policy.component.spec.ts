import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsolidatePolicyComponent } from './consolidate-policy.component';

describe('ConsolidatePolicyComponent', () => {
  let component: ConsolidatePolicyComponent;
  let fixture: ComponentFixture<ConsolidatePolicyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ConsolidatePolicyComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ConsolidatePolicyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

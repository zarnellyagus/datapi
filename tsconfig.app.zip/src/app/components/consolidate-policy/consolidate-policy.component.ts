import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PolicyService, ConsolidatePolicy, PagedResult } from '../../services/policy.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-consolidate-policy',
  standalone:false,
  templateUrl: './consolidate-policy.component.html',
  styleUrls: ['./consolidate-policy.component.scss']
})
export class ConsolidatePolicyComponent implements OnInit {
  policies: ConsolidatePolicy[] = [];
  searchPolicyId = '';
  searchAppNo = '';
  currentPage = 1;
  pageSize = 10;
  totalPages = 0;
  totalCount = 0;
  pageSizeOptions = [10, 25, 50, 100];
  isLoading = false;
  username = '';

  // Expose Math to template
  Math = Math;

  constructor(
    private policyService: PolicyService,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.username = this.authService.getUsername() || '';
    this.loadPolicies();
  }

  loadPolicies(): void {
    this.isLoading = true;
    this.policyService.getConsolidatePolicies(
      this.searchPolicyId || null,
      this.searchAppNo || null,
      this.currentPage,
      this.pageSize
    ).subscribe({
      next: (result: PagedResult<ConsolidatePolicy>) => {
        this.policies = result.data;
        this.totalPages = result.totalPages;
        this.totalCount = result.totalCount;
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Error loading policies:', err);
        this.isLoading = false;
      }
    });
  }

  onSearch(): void {
    this.currentPage = 1;
    this.loadPolicies();
  }

  onClearSearch(): void {
    this.searchPolicyId = '';
    this.searchAppNo = '';
    this.currentPage = 1;
    this.loadPolicies();
  }

  onPageChange(page: number): void {
    if (page < 1 || page > this.totalPages) return;
    this.currentPage = page;
    this.loadPolicies();
  }

  onPageSizeChange(): void {
    this.currentPage = 1;
    this.loadPolicies();
  }

  get pages(): number[] {
    const maxPages = 5;
    const pages: number[] = [];
    let startPage = Math.max(1, this.currentPage - Math.floor(maxPages / 2));
    let endPage = Math.min(this.totalPages, startPage + maxPages - 1);
    
    if (endPage - startPage < maxPages - 1) {
      startPage = Math.max(1, endPage - maxPages + 1);
    }
    
    for (let i = startPage; i <= endPage; i++) {
      pages.push(i);
    }
    return pages;
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}

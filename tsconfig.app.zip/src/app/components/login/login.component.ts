import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone:false,
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  username = '';
  password = '';
  errorMessage = '';
  isLoading = false;
  isAutoRedirecting = false;
  returnUrl = '/dashboard';
  showTraditionalLogin = false;

  constructor(
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    // Check if already authenticated
    if (this.authService.isAuthenticated()) {
      this.router.navigate(['/dashboard']);
      return;
    }

    // Get return URL from query params
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/dashboard';

    // Check for SSO error
    const error = this.route.snapshot.queryParams['error'];
    if (error) {
      this.errorMessage = this.getErrorMessage(error);
      this.showTraditionalLogin = true;
      return;
    }

    // Check if user wants traditional login
    const useTraditional = this.route.snapshot.queryParams['traditional'];
    if (useTraditional === 'true') {
      this.showTraditionalLogin = true;
      return;
    }

    // Auto-redirect to SSO after 2 seconds
    this.isAutoRedirecting = true;
    setTimeout(() => {
      this.loginWithSSO();
    }, 2000);
  }

  /**
   * Traditional login with username/password
   */
  onSubmit(): void {
    if (!this.username || !this.password) {
      this.errorMessage = 'Please enter username and password';
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';

    this.authService.login({ username: this.username, password: this.password })
      .subscribe({
        next: () => {
          this.router.navigate([this.returnUrl]);
        },
        error: (err) => {
          this.isLoading = false;
          this.errorMessage = err.error?.message || 'Login failed. Please check credentials.';
        }
      });
  }

  /**
   * SSO Login - Redirect to Microsoft Entra ID
   */
  loginWithSSO(): void {
    this.isLoading = true;
    this.errorMessage = '';
    this.authService.loginWithSSO();
  }

  /**
   * Show traditional login form
   */
  showManualLogin(): void {
    this.isAutoRedirecting = false;
    this.showTraditionalLogin = true;
  }

  /**
   * Get user-friendly error message
   */
  private getErrorMessage(errorCode: string): string {
    const errorMessages: { [key: string]: string } = {
      'authentication_failed': 'SSO authentication failed. Please try again.',
      'no_user_data': 'Unable to retrieve user information from SSO.',
      'callback_error': 'An error occurred during SSO login. Please try again.'
    };

    return errorMessages[errorCode] || 'An unknown error occurred during SSO login.';
  }
}

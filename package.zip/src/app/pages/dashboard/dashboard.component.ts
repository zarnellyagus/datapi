import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MenuService } from '../../services/menu.service';
import { Menu } from '../../models/menu.model';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  menus: Menu[] = [];

  constructor(private menuService: MenuService) {}

  ngOnInit(): void {
    this.loadMenus();
  }

  loadMenus(): void {
    this.menuService.getMenus().subscribe({
      next: (data) => {
        this.menus = data;
      },
      error: (err) => {
        console.error('Error loading menus:', err);
      }
    });
  }

  getMenuRoute(menuName: string): string {
    return '/' + menuName.toLowerCase().replace(/\s+/g, '-');
  }
}

import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { Company } from '../../models/auth.model';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  userName: string = '';
  password: string = '';
  selectedCompany: string = '';
  companies: Company[] = [];
  errorMessage: string = '';
  isLoading: boolean = false;
  isLoadingCompanies: boolean = true;

  constructor(
    private authService: AuthService,
    private router: Router
  ) {
    console.log('LoginComponent constructor called');
  }

  ngOnInit(): void {
    console.log('LoginComponent ngOnInit called');
    this.loadCompanies();
  }

  loadCompanies(): void {
    this.isLoadingCompanies = true;
    this.errorMessage = '';
    
    console.log('loadCompanies() called');
    
    this.authService.getCompanies().subscribe({
      next: (data) => {
        console.log('=== RAW DATA FROM API ===');
        console.log('Type of data:', typeof data);
        console.log('Is array:', Array.isArray(data));
        console.log('Data:', data);
        console.log('JSON stringified:', JSON.stringify(data, null, 2));
        
        // Check if data exists
        if (data) {
          console.log('Data length:', data.length);
          
          // Log each company
          data.forEach((company, index) => {
            console.log(`Company ${index}:`, company);
            console.log(`  - CompanyID:`, company.companyID);
            console.log(`  - CompanyName:`, company.companyName);
            console.log(`  - Keys:`, Object.keys(company));
          });
        }
        
        // Assign to component variable
        this.companies = data || [];
        console.log('=== ASSIGNED TO COMPONENT ===');
        console.log('this.companies:', this.companies);
        console.log('this.companies length:', this.companies.length);
        
        if (this.companies && this.companies.length > 0) {
          this.selectedCompany = this.companies[0].companyID;
          console.log('Selected company:', this.selectedCompany);
        } else {
          console.warn('No companies available after assignment');
          this.errorMessage = 'No companies available';
        }
        
        this.isLoadingCompanies = false;
        console.log('isLoadingCompanies set to false');
      },
      error: (err) => {
        console.error('=== ERROR LOADING COMPANIES ===');
        console.error('Full error:', err);
        console.error('Error status:', err.status);
        console.error('Error message:', err.message);
        
        this.isLoadingCompanies = false;
        
        if (err.status === 0) {
          this.errorMessage = 'Cannot connect to server at https://localhost:7227';
        } else if (err.status === 404) {
          this.errorMessage = 'API endpoint not found (404)';
        } else {
          this.errorMessage = `Failed to load companies: ${err.message || 'Unknown error'}`;
        }
      }
    });
  }

  onSubmit(): void {
    if (!this.selectedCompany) {
      this.errorMessage = 'Please select a company';
      return;
    }

    this.errorMessage = '';
    this.isLoading = true;

    this.authService.login({
      userName: this.userName,
      password: this.password,
      companyID: this.selectedCompany
    }).subscribe({
      next: (response) => {
        this.isLoading = false;
        if (response.success) {
          this.router.navigate(['/dashboard']);
        } else {
          this.errorMessage = response.message;
        }
      },
      error: (err) => {
        this.isLoading = false;
        if (err.status === 0) {
          this.errorMessage = 'Cannot connect to server';
        } else if (err.status === 401) {
          this.errorMessage = 'Invalid username or password';
        } else {
          this.errorMessage = err.error?.message || 'Login failed';
        }
      }
    });
  }

  retryLoadCompanies(): void {
    this.loadCompanies();
  }

  // Method untuk test dari template
  testCompanies(): void {
    console.log('=== TEST FROM TEMPLATE ===');
    console.log('companies:', this.companies);
    console.log('companies length:', this.companies?.length);
  }
}

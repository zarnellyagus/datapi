import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { PolicyService } from '../../services/policy.service';
import { 
  ConsolidatePolicyInfo,
  ConsolidateStatus,
  ConsolidateSummary 
} from '../../models/policy.model';

@Component({
  selector: 'app-policy-detail',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './policy-detail.component.html',
  styleUrls: ['./policy-detail.component.scss']
})
export class PolicyDetailComponent implements OnInit {
  policyId: string = '';
  policyInfo: ConsolidatePolicyInfo | null = null;
  policyStatus: ConsolidateStatus[] = [];
  policySummary: ConsolidateSummary | null = null;
  activeTab: string = 'info';
  isLoading: boolean = false;

  constructor(
    private route: ActivatedRoute,
    private policyService: PolicyService
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.policyId = params['id'];
      this.loadPolicyData();
    });
  }

  loadPolicyData(): void {
    this.isLoading = true;
    
    // Load Policy Info
    this.policyService.getPolicyInfo(this.policyId).subscribe({
      next: (data) => {
        this.policyInfo = data;
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Error loading policy info:', err);
        this.isLoading = false;
      }
    });

    // Load Policy Status
    this.policyService.getPolicyStatus(this.policyId).subscribe({
      next: (data) => {
        this.policyStatus = data;
      },
      error: (err) => {
        console.error('Error loading policy status:', err);
      }
    });

    // Load Policy Summary
    this.policyService.getPolicySummary(this.policyId).subscribe({
      next: (data) => {
        this.policySummary = data;
      },
      error: (err) => {
        console.error('Error loading policy summary:', err);
      }
    });
  }

  setActiveTab(tab: string): void {
    this.activeTab = tab;
  }
}

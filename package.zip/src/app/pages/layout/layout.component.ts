import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { MenuService } from '../../services/menu.service';
import { Menu } from '../../models/menu.model';
import { UserData } from '../../models/auth.model';

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss']
})
export class LayoutComponent implements OnInit {
  isSidebarCollapsed = false;
  menus: Menu[] = [];
  currentUser: UserData | null = null;

  constructor(
    private authService: AuthService,
    private menuService: MenuService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadMenus();
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }

  loadMenus(): void {
    this.menuService.getMenus().subscribe({
      next: (data) => {
        this.menus = data;
      },
      error: (err) => {
        console.error('Error loading menus:', err);
      }
    });
  }

  toggleSidebar(): void {
    this.isSidebarCollapsed = !this.isSidebarCollapsed;
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  getMenuRoute(menuName: string): string {
    return '/' + menuName.toLowerCase().replace(/\s+/g, '-');
  }
}

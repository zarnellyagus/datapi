import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { PolicyService } from '../../services/policy.service';
import { DetailPolicy, PagedResult } from '../../models/policy.model';

@Component({
  selector: 'app-consolidate-policy',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './consolidate-policy.component.html',
  styleUrls: ['./consolidate-policy.component.scss']
})
export class ConsolidatePolicyComponent implements OnInit {
  policies: DetailPolicy[] = [];
  policyId: string = '';
  appNo: string = '';
  pageNumber: number = 1;
  pageSize: number = 10;
  totalRecords: number = 0;
  totalPages: number = 0;
  pageSizes: number[] = [10, 25, 50, 100];
  isLoading: boolean = false;

  constructor(private policyService: PolicyService) {}

  ngOnInit(): void {
    this.searchPolicies();
  }

  searchPolicies(): void {
    this.isLoading = true;
    this.policyService.getDetailPolicies(
      this.policyId,
      this.appNo,
      this.pageNumber,
      this.pageSize
    ).subscribe({
      next: (result: PagedResult<DetailPolicy>) => {
        this.policies = result.data;
        this.totalRecords = result.totalRecords;
        this.totalPages = result.totalPages;
        this.pageNumber = result.pageNumber;
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Error loading policies:', err);
        this.isLoading = false;
      }
    });
  }

  onSearch(): void {
    this.pageNumber = 1;
    this.searchPolicies();
  }

  onPageSizeChange(): void {
    this.pageNumber = 1;
    this.searchPolicies();
  }

  goToPage(page: number): void {
    if (page >= 1 && page <= this.totalPages) {
      this.pageNumber = page;
      this.searchPolicies();
    }
  }

  get pages(): number[] {
    const maxPages = 5;
    const pages: number[] = [];
    let startPage = Math.max(1, this.pageNumber - Math.floor(maxPages / 2));
    let endPage = Math.min(this.totalPages, startPage + maxPages - 1);

    if (endPage - startPage < maxPages - 1) {
      startPage = Math.max(1, endPage - maxPages + 1);
    }

    for (let i = startPage; i <= endPage; i++) {
      pages.push(i);
    }

    return pages;
  }
}

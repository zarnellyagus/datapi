export interface LoginRequest {
  userName: string;
  password: string;
  companyID: string;
}

export interface LoginResponse {
  success: boolean;
  message: string;
  token: string;
  user: UserData;
}

export interface UserData {
  userID: string;
  userName: string;
  companyID: string;
  companyName: string;
}

export interface Company {
  companyID: string;   // Jika API return PascalCase
  companyName: string;
}


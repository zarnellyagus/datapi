export interface DetailPolicy {
  companyID: string;
  policyID: string;
  appNo: string;
  ownerName: string;
  issuedDate: Date;
}

export interface PagedResult<T> {
  data: T[];
  totalRecords: number;
  pageNumber: number;
  pageSize: number;
  totalPages: number;
}

export interface ConsolidatePolicyInfo {
  spajNo: string;
  policyNo: string;
  clientID: string;
  ownerName: string;
  insuredName: string;
  planName: string;
  issuedDate: Date;
  agentId: string;
  branchName: string;
  email: string;
  tlpNum: string;
  ttp: string;
  receiveDate: string;
}

export interface ConsolidateStatus {
  polSumPolicyID: string;
  polSumPickUpDate: Date;
  polSumStatusDate: Date;
  polSumStatus: string;
  polSumReceiver: string;
  polSumRelation: string;
  polSumReturn: string;
  polSumResiNo: string;
  polSumCourier: string;
}

export interface ConsolidateSummary {
  polSumPolicyID: string;
  polSumPickUpDate: Date;
  polSumStatusDate: Date;
  polSumStatus: string;
  polSumReceiver: string;
  polSumRelation: string;
  polSumReturn: string;
  polSumResiNo: string;
  polSumCourier: string;
}

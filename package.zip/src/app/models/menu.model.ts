export interface Menu {
  objectID: number;
  objectName: string;
}

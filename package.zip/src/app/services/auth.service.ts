import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { LoginRequest, LoginResponse, Company, UserData } from '../models/auth.model';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  // UPDATE: Gunakan port 7227 dengan HTTPS
  private apiUrl = 'https://localhost:7227/api';
  private currentUserSubject = new BehaviorSubject<UserData | null>(null);
  public currentUser$ = this.currentUserSubject.asObservable();

  constructor(private http: HttpClient) {
    const user = this.getUserFromStorage();
    if (user) {
      this.currentUserSubject.next(user);
    }
  }

  login(request: LoginRequest): Observable<LoginResponse> {
    console.log('Login API URL:', `${this.apiUrl}/Auth/login`);
    return this.http.post<LoginResponse>(`${this.apiUrl}/Auth/login`, request)
      .pipe(
        tap(response => {
          console.log('Login response:', response);
          if (response.success) {
            localStorage.setItem('token', response.token);
            localStorage.setItem('user', JSON.stringify(response.user));
            this.currentUserSubject.next(response.user);
          }
        }),
        catchError(error => {
          console.error('Login error:', error);
          return throwError(() => error);
        })
      );
  }

  getCompanies(): Observable<Company[]> {
    console.log('Getting companies from:', `${this.apiUrl}/Auth/companies`);
    return this.http.get<Company[]>(`${this.apiUrl}/Auth/companies`)
      .pipe(
        tap(data => console.log('Companies received:', data)),
        catchError(error => {
          console.error('Error getting companies:', error);
          return throwError(() => error);
        })
      );
  }

  logout(): void {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    this.currentUserSubject.next(null);
  }

  getToken(): string | null {
    return localStorage.getItem('token');
  }

  getUserFromStorage(): UserData | null {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
  }

  isAuthenticated(): boolean {
    return !!this.getToken();
  }
}

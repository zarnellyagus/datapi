import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { 
  DetailPolicy, 
  PagedResult, 
  ConsolidatePolicyInfo,
  ConsolidateStatus,
  ConsolidateSummary 
} from '../models/policy.model';

@Injectable({
  providedIn: 'root'
})
export class PolicyService {
  private apiUrl = 'https://localhost:7227/api/consolidatepolicy';

  constructor(private http: HttpClient) {}

  getDetailPolicies(policyId: string, appNo: string, pageNumber: number, pageSize: number): Observable<PagedResult<DetailPolicy>> {
    const body = {
      policyId: policyId || null,
      appNo: appNo || null,
      pageNumber,
      pageSize
    };
    return this.http.post<PagedResult<DetailPolicy>>(`${this.apiUrl}/detail-policies`, body);
  }

  getPolicyInfo(policyId: string): Observable<ConsolidatePolicyInfo> {
    return this.http.get<ConsolidatePolicyInfo>(`${this.apiUrl}/policy-info/${policyId}`);
  }

  getPolicyStatus(policyId: string): Observable<ConsolidateStatus[]> {
    return this.http.get<ConsolidateStatus[]>(`${this.apiUrl}/policy-status/${policyId}`);
  }

  getPolicySummary(policyId: string): Observable<ConsolidateSummary> {
    return this.http.get<ConsolidateSummary>(`${this.apiUrl}/policy-summary/${policyId}`);
  }
}

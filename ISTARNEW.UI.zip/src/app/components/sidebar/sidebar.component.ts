import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { MenuService } from '../../services/menu.service';
import { AuthService } from '../../services/auth.service';
import { MenuItem } from '../../models/menu.model';

@Component({
  selector: 'app-sidebar',
  standalone:false,
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
  @Input() isCollapsed = false;
  @Output() toggleSidebar = new EventEmitter<boolean>();

  menuItems: MenuItem[] = [];
  loading = true;
  currentRoute = '';

  // Default static menu items (fallback)
  defaultMenuItems: MenuItem[] = [
    {
      objectId: '1',
      objectName: 'Dashboard',
      route: '/dashboard',
      icon: 'bi-speedometer2'
    },
    {
      objectId: '2',
      objectName: 'Consolidate Policy',
      route: '/consolidate-policy',
      icon: 'bi-file-earmark-text'
    }
  ];

  constructor(
    private menuService: MenuService,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadMenu();
    this.trackCurrentRoute();
  }

  loadMenu(): void {
    const userId = this.authService.currentUserValue?.userId;
    
    if (userId) {
      this.menuService.getUserMenu(userId).subscribe({
        next: (menuItems) => {
          // Service sekarang langsung return MenuItem[]
          if (menuItems && menuItems.length > 0) {
            this.menuItems = this.mapMenuItems(menuItems);
          } else {
            // Fallback ke default menu
            this.menuItems = this.defaultMenuItems;
          }
          this.loading = false;
        },
        error: (error) => {
          console.error('Error loading menu:', error);
          // Fallback ke default menu
          this.menuItems = this.defaultMenuItems;
          this.loading = false;
        }
      });
    } else {
      // Fallback ke default menu
      this.menuItems = this.defaultMenuItems;
      this.loading = false;
    }
  }

  private mapMenuItems(data: MenuItem[]): MenuItem[] {
    const menuMap: Record<string, { route: string; icon: string }> = {
      'Dashboard': { route: '/dashboard', icon: 'bi-speedometer2' },
      'Consolidate Policy': { route: '/consolidate-policy', icon: 'bi-file-earmark-text' },
      'Policy Summary': { route: '/policy-summary', icon: 'bi-file-text' },
      'Reports': { route: '/reports', icon: 'bi-graph-up' },
      'Settings': { route: '/settings', icon: 'bi-gear' }
    };

    return data.map(item => {
      const objectName = item.objectName || item.objectName;
      const mapped = menuMap[objectName];

      return {
        objectId: item.objectId || item.objectId,
        objectName: objectName,
        route: mapped?.route || '#',
        icon: mapped?.icon || 'bi-circle'
      };
    });
  }

  private trackCurrentRoute(): void {
    this.currentRoute = this.router.url;
    
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: any) => {
      this.currentRoute = event.urlAfterRedirects;
    });
  }

  isActive(route: string): boolean {
    return this.currentRoute === route;
  }

  toggle(): void {
    this.isCollapsed = !this.isCollapsed;
    this.toggleSidebar.emit(this.isCollapsed);
  }

  navigateTo(route: string): void {
    if (route !== '#') {
      this.router.navigate([route]);
    }
  }
}

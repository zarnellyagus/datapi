import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PolicyService } from '../../services/policy.service';
import { 
  ConsolidatePolicy, 
  PolicySearchRequest, 
  PagedResult 
} from '../../models/policy.model';

@Component({
  selector: 'app-consolidate-policy',
  standalone:false,
  templateUrl: './consolidate-policy.component.html',
  styleUrls: ['./consolidate-policy.component.scss']
})
export class ConsolidatePolicyComponent implements OnInit {
  policies: ConsolidatePolicy[] = [];
  loading = false;
  
  searchRequest: PolicySearchRequest = {
    policyId: '',
    appNo: '',
    pageNumber: 1,
    pageSize: 10
  };

  totalRecords = 0;
  totalPages = 0;
  pageSizes = [10, 25, 50, 100];

  constructor(
    private policyService: PolicyService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.searchPolicies();
  }

  searchPolicies(): void {
    this.loading = true;
    this.policyService.searchPolicies(this.searchRequest).subscribe({
      next: (response) => {
        if (response.success) {
          this.policies = response.data.data;
          this.totalRecords = response.data.totalRecords;
          this.totalPages = response.data.totalPages;
          this.searchRequest.pageNumber = response.data.currentPage;
        }
        this.loading = false;
      },
      error: () => {
        this.loading = false;
      }
    });
  }

  onSearch(): void {
    this.searchRequest.pageNumber = 1;
    this.searchPolicies();
  }

  onPageChange(page: number): void {
    this.searchRequest.pageNumber = page;
    this.searchPolicies();
  }

  onPageSizeChange(): void {
    this.searchRequest.pageNumber = 1;
    this.searchPolicies();
  }

  viewDetail(policyId: string): void {
    this.router.navigate(['/policy-detail', policyId]);
  }

  get pages(): number[] {
    return Array.from({ length: this.totalPages }, (_, i) => i + 1);
  }
}

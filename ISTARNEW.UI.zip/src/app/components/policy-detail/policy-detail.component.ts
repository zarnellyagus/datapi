import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PolicyService } from '../../services/policy.service';
import { PolicyInfo, EPolicy, PolicySummary } from '../../models/policy.model';

@Component({
  selector: 'app-policy-detail',
  standalone:false,
  templateUrl: './policy-detail.component.html',
  styleUrls: ['./policy-detail.component.scss']
})
export class PolicyDetailComponent implements OnInit {
  policyId: string = '';
  loading = true;
  activeTab = 'policy-info';

  policyInfo: PolicyInfo | null = null;
  ePolicyInfo: EPolicy[] = [];
  policySummary: PolicySummary | null = null;

  constructor(
    private route: ActivatedRoute,
    private policyService: PolicyService
  ) {}

  ngOnInit(): void {
    this.policyId = this.route.snapshot.paramMap.get('id') || '';
    this.loadPolicyDetail();
  }

  loadPolicyDetail(): void {
    this.loading = true;
    this.policyService.getPolicyDetail(this.policyId).subscribe({
      next: (response) => {
        if (response.success) {
          this.policyInfo = response.data.policyInfo;
          this.ePolicyInfo = response.data.ePolicyInfo;
          this.policySummary = response.data.policySummary;
        }
        this.loading = false;
      },
      error: () => {
        this.loading = false;
      }
    });
  }

  setActiveTab(tab: string): void {
    this.activeTab = tab;
  }
}

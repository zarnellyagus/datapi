import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { tap, catchError, shareReplay } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { 
  PolicySearchRequest, 
  PagedResult, 
  ConsolidatePolicy,
  PolicyInfo,
  EPolicy,
  PolicySummary 
} from '../models/policy.model';

@Injectable({
  providedIn: 'root'
})
export class PolicyService {
  private policyCache: Map<string, any> = new Map();
  private cacheTimeout = 5 * 60 * 1000; // 5 minutes

  constructor(private http: HttpClient) {}

  searchPolicies(request: PolicySearchRequest): Observable<any> {
    return this.http.post<any>(
      `${environment.apiUrl}/ConsolidatePolicy/search`,
      request
    ).pipe(
      catchError(error => {
        console.error('Error searching policies:', error);
        return of({ success: false, data: null });
      })
    );
  }

  getPolicyDetail(policyId: string): Observable<any> {
    const cacheKey = `policy_${policyId}`;
    const cached = this.policyCache.get(cacheKey);

    if (cached && (Date.now() - cached.timestamp < this.cacheTimeout)) {
      return of(cached.data);
    }

    return this.http.get<any>(
      `${environment.apiUrl}/ConsolidatePolicy/detail/${policyId}`
    ).pipe(
      tap(response => {
        this.policyCache.set(cacheKey, {
          data: response,
          timestamp: Date.now()
        });
      }),
      shareReplay(1),
      catchError(error => {
        console.error('Error fetching policy detail:', error);
        return of({ success: false, data: null });
      })
    );
  }

  clearCache(): void {
    this.policyCache.clear();
  }
}

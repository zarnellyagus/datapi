import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError, shareReplay } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { MenuItem } from '../models/menu.model';

// Response interface yang match dengan backend
interface MenuApiItem {
  Objectid: string;
  ObjectName: string;
}

interface MenuResponse {
  success: boolean;
  data: MenuApiItem[];
}

@Injectable({
  providedIn: 'root'
})
export class MenuService {
  private menuCache$: Observable<MenuItem[]> | null = null;

  constructor(private http: HttpClient) {}

  getUserMenu(userId: string, forceRefresh = false): Observable<MenuItem[]> {
    if (!this.menuCache$ || forceRefresh) {
      this.menuCache$ = this.http
        .get<MenuResponse>(`${environment.apiUrl}/Menu/user-menu/${userId}`)
        .pipe(
          map(response => {
            if (response.success && response.data) {
              // Transform backend data to frontend model
              return response.data.map(item => this.transformMenuItem(item));
            }
            return [];
          }),
          shareReplay(1),
          catchError(error => {
            console.error('Error fetching menu:', error);
            return of([]);
          })
        );
    }
    return this.menuCache$;
  }

  /**
   * Transform backend menu item to frontend model
   */
  private transformMenuItem(apiItem: MenuApiItem): MenuItem {
    const menuMap: Record<string, { route: string; icon: string }> = {
      'Dashboard': { route: '/dashboard', icon: 'bi-speedometer2' },
      'Consolidate Policy': { route: '/consolidate-policy', icon: 'bi-file-earmark-text' },
      'Policy Summary': { route: '/policy-summary', icon: 'bi-file-text' },
      'Reports': { route: '/reports', icon: 'bi-graph-up' },
      'Settings': { route: '/settings', icon: 'bi-gear' }
    };

    const mapped = menuMap[apiItem.ObjectName];

    return {
      objectId: apiItem.Objectid,
      objectName: apiItem.ObjectName,
      route: mapped?.route || '#',
      icon: mapped?.icon || 'bi-circle'
    };
  }

  clearCache(): void {
    this.menuCache$ = null;
  }
}

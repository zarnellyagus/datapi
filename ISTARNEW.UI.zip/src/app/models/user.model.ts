export interface User {
  userId: string;
  userName: string;
  email?: string;
}

export interface LoginResponse {
  token: string;
  userId: string;
  userName: string;
  expiresAt: Date;
}

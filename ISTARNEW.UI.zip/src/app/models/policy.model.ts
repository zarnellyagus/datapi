export interface ConsolidatePolicy {
  companyID: string;
  policyID: string;
  appNo: string;
  ownerName: string;
  issuedDate: Date;
}

export interface PolicySearchRequest {
  policyId?: string;
  appNo?: string;
  pageNumber: number;
  pageSize: number;
}

export interface PagedResult<T> {
  data: T[];
  totalRecords: number;
  totalPages: number;
  currentPage: number;
  pageSize: number;
}

export interface PolicyInfo {
  spajNo: string;
  policyNo: string;
  clientID: string;
  ownerName: string;
  insuredName: string;
  planName: string;
  issuedDate: Date;
  agentId: string;
  branchName: string;
  addressName: string;
  email: string;
  tlpNum: string;
  ttp: string;
  receiveDate: string;
}

export interface EPolicy {
  ePolSource: string;
  statusDate: Date;
  status: string;
}

export interface PolicySummary {
  polSumPolicyID: string;
  polSumPickUpDate: Date;
  polSumStatusDate: Date;
  polSumStatus: string;
  polSumReceiver: string;
  polSumRelation: string;
  polSumReturn: string;
  polSumResiNo: string;
  polSumCourier: string;
}

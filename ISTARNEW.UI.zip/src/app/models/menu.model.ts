export interface MenuItem {
  objectId: string;
  objectName: string;
  route?: string;
  icon?: string;
}

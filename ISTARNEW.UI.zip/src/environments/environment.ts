export const environment = {
  production: false,
  apiUrl: 'http://localhost:7068/api',
  ssoLoginUrl: 'http://localhost:7068/api/auth-service/sso-login'
};

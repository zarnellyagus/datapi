﻿using Dapper;
using System.Data.SqlClient;
using Microsoft.Extensions.Caching.Memory;
using CompdtBEAPI.Models;

namespace CompdtBEAPI.Services
{
   
    public class MenuService : IMenuService
    {
        private readonly IConfiguration _configuration;
        private readonly IMemoryCache _cache;

        public MenuService(IConfiguration configuration, IMemoryCache cache)
        {
            _configuration = configuration;
            _cache = cache;
        }

        public async Task<List<MenuObject>> GetUserMenuAsync(string userId)
        {
            // Cache key berdasarkan userId
            var cacheKey = $"UserMenu_{userId}";

            // Cek cache terlebih dahulu
            if (_cache.TryGetValue(cacheKey, out List<MenuObject> cachedMenu))
            {
                return cachedMenu;
            }

            // Query yang dioptimasi dengan NOLOCK untuk performa
            var sql = @"
                SELECT DISTINCT 
                    a.Objectid, 
                    a.ObjectName
                FROM tobject a WITH (NOLOCK)
                INNER JOIN trole_detail b WITH (NOLOCK)
                    ON a.ObjectID = b.ObjectID AND a.CompanyID = b.CompanyID
                INNER JOIN trole c WITH (NOLOCK)
                    ON b.RoleID = c.RoleID AND b.CompanyID = c.CompanyID
                INNER JOIN tuser_role d WITH (NOLOCK)
                    ON d.RoleID = c.RoleID AND d.CompanyID = c.CompanyID
                INNER JOIN tuser e WITH (NOLOCK)
                    ON e.userid = d.userid AND e.companyid = d.companyid
                WHERE e.userid = @userid
                ORDER BY a.ObjectName";

            using (var connection = new SqlConnection(_configuration.GetConnectionString("NDISIS02")))
            {
                var menus = (await connection.QueryAsync<MenuObject>(sql, new { userid = userId })).ToList();

                // Simpan ke cache selama 30 menit
                var cacheOptions = new MemoryCacheEntryOptions()
                    .SetAbsoluteExpiration(TimeSpan.FromMinutes(30));

                _cache.Set(cacheKey, menus, cacheOptions);

                return menus;
            }
        }
    }
}

﻿using Dapper;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Extensions.Caching.Memory;
using CompdtBEAPI.Models;

namespace CompdtBEAPI.Services
{
   
    public class ConsolidatePolicyService : IConsolidatePolicyService
    {
        private readonly IConfiguration _configuration;
        private readonly IMemoryCache _cache;

        public ConsolidatePolicyService(IConfiguration configuration, IMemoryCache cache)
        {
            _configuration = configuration;
            _cache = cache;
        }

        public async Task<PagedResult<ConsolidatePolicyList>> GetConsolidatePoliciesAsync(ConsolidatePolicySearchRequest request)
        {
            // Query yang dioptimasi dengan:
            // 1. NOLOCK untuk menghindari locking
            // 2. OPENQUERY untuk linked server performance
            // 3. Pagination di database level
            // 4. Selective columns untuk mengurangi data transfer
            var sql = @"
                WITH PolicyData AS (
                    SELECT
                        'CP' AS CompanyID,
                        tce.EPolPolicyID AS PolicyID,
                        dpi.POL_APP_FORM_ID AS AppNo,
                        ISNULL(dpi.OWN_FIRST_NAME,'') + ISNULL(dpi.OWN_LAST_NAME,'') AS OwnerName,
                        dpi.POL_ISS_EFF_DT AS IssuedDate,
                        ROW_NUMBER() OVER (ORDER BY tce.EPolDate DESC) AS RowNum
                    FROM dbo.tconsolidate_epolicy tce WITH (NOLOCK)
                    LEFT JOIN [LNKSV801041].NDIBORD02.dbo.DWM_POLICY_INFO dpi WITH (NOLOCK)
                        ON tce.EPolPolicyID = dpi.POL_ID AND dpi.CO_ID = 'CP'
                    WHERE 
                        (@policyId IS NULL OR tce.EPolPolicyID LIKE '%' + @policyId + '%')
                        AND (@appNo IS NULL OR dpi.POL_APP_FORM_ID LIKE '%' + @appNo + '%')
                )
                SELECT 
                    CompanyID, PolicyID, AppNo, OwnerName, IssuedDate
                FROM PolicyData
                WHERE RowNum BETWEEN @StartRow AND @EndRow
                ORDER BY RowNum;

                -- Get total count
                SELECT COUNT(*) 
                FROM dbo.tconsolidate_epolicy tce WITH (NOLOCK)
                LEFT JOIN [LNKSV801041].NDIBORD02.dbo.DWM_POLICY_INFO dpi WITH (NOLOCK)
                    ON tce.EPolPolicyID = dpi.POL_ID AND dpi.CO_ID = 'CP'
                WHERE 
                    (@policyId IS NULL OR tce.EPolPolicyID LIKE '%' + @policyId + '%')
                    AND (@appNo IS NULL OR dpi.POL_APP_FORM_ID LIKE '%' + @appNo + '%');";

            var startRow = (request.PageNumber - 1) * request.PageSize + 1;
            var endRow = request.PageNumber * request.PageSize;

            using (var connection = new SqlConnection(_configuration.GetConnectionString("NDIPRINT33")))
            {
                await connection.OpenAsync();

                using (var multi = await connection.QueryMultipleAsync(sql, new
                {
                    policyId = string.IsNullOrEmpty(request.PolicyId) ? null : request.PolicyId,
                    appNo = string.IsNullOrEmpty(request.AppNo) ? null : request.AppNo,
                    StartRow = startRow,
                    EndRow = endRow
                }, commandTimeout: 30))
                {
                    var data = (await multi.ReadAsync<ConsolidatePolicyList>()).ToList();
                    var totalRecords = await multi.ReadSingleAsync<int>();

                    return new PagedResult<ConsolidatePolicyList>
                    {
                        Data = data,
                        TotalRecords = totalRecords,
                        TotalPages = (int)Math.Ceiling(totalRecords / (double)request.PageSize),
                        CurrentPage = request.PageNumber,
                        PageSize = request.PageSize
                    };
                }
            }
        }

        public async Task<PolicyInfo> GetPolicyInfoAsync(string policyId)
        {
            var cacheKey = $"PolicyInfo_{policyId}";

            if (_cache.TryGetValue(cacheKey, out PolicyInfo cachedData))
            {
                return cachedData;
            }

            // Optimized query dengan NOLOCK dan selective columns
            var sql = @"
                SELECT TOP 1
                    msa.spaj_no AS SpajNo,
                    dpi.POL_ID AS PolicyNo,
                    dpi.INS_CLI_ID AS ClientID,
                    LTRIM(RTRIM(ISNULL(dpi.OWN_FIRST_NAME,'') + ' ' + ISNULL(dpi.OWN_MIDDLE_NAME,'') + ' ' + ISNULL(dpi.OWN_LAST_NAME,''))) AS OwnerName,
                    LTRIM(RTRIM(ISNULL(dpi.INS_FIRST_NAME,'') + ' ' + ISNULL(dpi.INS_MIDDLE_NAME,'') + ' ' + ISNULL(dpi.INS_LAST_NAME,''))) AS InsuredName,
                    dpp.PLAN_NM AS PlanName,
                    dpi.POL_ISS_EFF_DT AS IssuedDate,
                    dpi.SERV_AGT_ID AS AgentId,
                    ISNULL(dpi.SERV_BR_ID,'') + ' - ' + ISNULL(dat.TEAM_NM,'') AS BranchName,
                    '' AS AddressName,
                    CASE WHEN tcen.EPolSource = 'Email' THEN tcen.EPolDest ELSE '' END AS Email,
                    CASE WHEN tcen.EPolSource = 'WA' THEN tcen.EPolDest ELSE '' END AS TlpNum,
                    CASE WHEN msa.ettp_received_date IS NULL THEN 'Paper' ELSE 'ETTP' END AS Ttp,
                    CASE
                        WHEN msa.ettp_received_date IS NULL THEN ISNULL(CONVERT(CHAR(11), msa.ho_received_date, 106),'')
                        ELSE ISNULL(CONVERT(CHAR(11), msa.ettp_received_date, 106),'')
                    END AS ReceiveDate
                FROM dbo.tconsolidate_epolicy tcen WITH (NOLOCK)
                LEFT JOIN [LINKTOSV80431].NDTRAX02.dbo.MST_SPAJ_ACCOUNT msa WITH (NOLOCK) 
                    ON tcen.EPolPolicyID = msa.[policy_no]
                LEFT JOIN [LNKSV801041].NDIBORD02.dbo.DWM_POLICY_INFO dpi WITH (NOLOCK) 
                    ON tcen.EPolPolicyID = dpi.POL_ID AND dpi.CO_ID='CP'
                LEFT JOIN [LNKSV801041].NDIBORD02.dbo.DWM_PLAN_INFO dpp WITH (NOLOCK) 
                    ON dpp.PLAN_ID = dpi.PLAN_ID AND dpi.CO_ID='CP'
                LEFT JOIN [LNKSV801041].NDIBORD02.DBO.DWM_AGENCY_TEAM dat WITH (NOLOCK) 
                    ON dpi.SERV_BR_ID = dat.TEAM_CD AND dat.CO_ID='CP'
                WHERE dpi.POL_ID = @PolicyID";

            using (var connection = new SqlConnection(_configuration.GetConnectionString("NDIPRINT33")))
            {
                var result = await connection.QueryFirstOrDefaultAsync<PolicyInfo>(sql, new { PolicyID = policyId }, commandTimeout: 30);

                if (result != null)
                {
                    _cache.Set(cacheKey, result, TimeSpan.FromMinutes(15));
                }

                return result ?? new PolicyInfo();
            }
        }

        public async Task<List<EPolicy>> GetEPolicyInfoAsync(string policyId)
        {
            var sql = @"
                SELECT 
                    EPolSource, 
                    MAX(EPolDate) AS StatusDate, 
                    MAX(EPolStatus) AS Status
                FROM tconsolidate_epolicy WITH (NOLOCK)
                WHERE EPolPolicyID = @PolicyID
                GROUP BY EPolSource, EPolDate, EPolStatus
                ORDER BY StatusDate DESC";

            using (var connection = new SqlConnection(_configuration.GetConnectionString("NDIPRINT33")))
            {
                var result = await connection.QueryAsync<EPolicy>(sql, new { PolicyID = policyId }, commandTimeout: 30);
                return result.ToList();
            }
        }

        public async Task<PolicySummary> GetPolicySummaryAsync(string policyId)
        {
            var sql = @"
                SELECT TOP 1
                    tcps.PolSumPolicyID, 
                    tcps.PolSumPickUpDate, 
                    tcps.PolSumStatusDate, 
                    tcps.PolSumStatus, 
                    tcps.PolSumReceiver,
                    tcps.PolSumRelation, 
                    tcps.PolSumReturn, 
                    tcps.PolSumResiNo, 
                    tcps.PolSumCourier 
                FROM tconsolidate_epolicy tcen WITH (NOLOCK)
                LEFT JOIN tconsolidate_policysummary tcps WITH (NOLOCK) 
                    ON tcen.EPolPolicyID = tcps.PolSumPolicyID
                WHERE tcps.PolSumPolicyID = @PolicyID";

            using (var connection = new SqlConnection(_configuration.GetConnectionString("NDIPRINT33")))
            {
                var result = await connection.QueryFirstOrDefaultAsync<PolicySummary>(
                    sql,
                    new { PolicyID = policyId },
                    commandTimeout: 30);

                // Return result atau default value jika null
                return result ?? new PolicySummary();
            }
        }
    }
}

﻿using CompdtBEAPI.Models;

namespace CompdtBEAPI.Services
{
    public interface IConsolidatePolicyService
    {
        Task<PagedResult<ConsolidatePolicyList>> GetConsolidatePoliciesAsync(ConsolidatePolicySearchRequest request);
        Task<PolicyInfo> GetPolicyInfoAsync(string policyId);
        Task<List<EPolicy>> GetEPolicyInfoAsync(string policyId);
        Task<PolicySummary> GetPolicySummaryAsync(string policyId);
    }

}

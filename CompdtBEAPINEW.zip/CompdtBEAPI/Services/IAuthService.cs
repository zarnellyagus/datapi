﻿using CompdtBEAPI.Models;

namespace CompdtBEAPI.Services
{
    public interface IAuthService
    {
        Task<LoginResponse> AuthenticateUserAsync(string userId);
        string GenerateJwtToken(string userId, string userName);
    }
}

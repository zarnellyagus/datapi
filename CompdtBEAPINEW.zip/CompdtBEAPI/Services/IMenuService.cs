﻿using CompdtBEAPI.Models;

namespace CompdtBEAPI.Services
{
    public interface IMenuService
    {
        Task<List<MenuObject>> GetUserMenuAsync(string userId);
    }

}

﻿namespace CompdtBEAPI.Models
{
    public class User
    {
        public string UserId { get; set; } = string.Empty;
        public string CompanyId { get; set; } = string.Empty;
        public string UserName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
    }
    public class LoginRequest
    {
        public string? UserId { get; set; }
        public string? CompanyId { get; set; }
    }
    public class LoginResponse
    {
        public string Token { get; set; } = string.Empty;
        public string UserId { get; set; } = string.Empty;
        public string UserName { get; set; } = string.Empty;
        public DateTime ExpiresAt { get; set; } 
    }
}

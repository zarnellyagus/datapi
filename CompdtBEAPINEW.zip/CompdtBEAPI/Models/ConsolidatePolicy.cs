﻿namespace CompdtBEAPI.Models
{
    public class ConsolidatePolicyList
    {
        public string CompanyID { get; set; } = string.Empty;
        public string PolicyID { get; set; } = string.Empty;
        public string AppNo { get; set; } = string.Empty;
        public string OwnerName { get; set; } = string.Empty;
        public DateTime? IssuedDate { get; set; } 
    }

    public class ConsolidatePolicySearchRequest
    {
        public string PolicyId { get; set; } = string.Empty;
        public string AppNo { get; set; } = string.Empty;
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 10;
    }

    public class PagedResult<T>
    {
        public List<T>? Data { get; set; } 
        public int TotalRecords { get; set; }
        public int TotalPages { get; set; } 
        public int CurrentPage { get; set; }
        public int PageSize { get; set; }
    }
}

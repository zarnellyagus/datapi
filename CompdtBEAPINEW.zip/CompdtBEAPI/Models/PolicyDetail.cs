﻿namespace CompdtBEAPI.Models
{
    public class PolicyInfo
    {
        public string SpajNo { get; set; } = string.Empty;
        public string PolicyNo { get; set; } = string.Empty;
        public string ClientID { get; set; } = string.Empty;
        public string OwnerName { get; set; } = string.Empty;
        public string InsuredName { get; set; } = string.Empty;
        public string PlanName { get; set; } = string.Empty;
        public DateTime? IssuedDate { get; set; }
        public string AgentId { get; set; } = string.Empty;
        public string BranchName { get; set; } = string.Empty;
        public string AddressName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string TlpNum { get; set; } = string.Empty;
        public string Ttp { get; set; } = string.Empty;
        public string ReceiveDate { get; set; } = string.Empty;
    }

    public class EPolicy
    {
        public string EPolSource { get; set; } = string.Empty;
        public DateTime? StatusDate { get; set; } 
        public string Status { get; set; } = string.Empty;
    } 

    public class PolicySummary
    {
        public string PolSumPolicyID { get; set; } = string.Empty;
        public DateTime? PolSumPickUpDate { get; set; }
        public DateTime? PolSumStatusDate { get; set; } 
        public string PolSumStatus { get; set; } = string.Empty;
        public string PolSumReceiver { get; set; } = string.Empty;
        public string PolSumRelation { get; set; } = string.Empty;
        public string PolSumReturn { get; set; } = string.Empty;
        public string PolSumResiNo { get; set; } = string.Empty;
        public string PolSumCourier { get; set; } = string.Empty;
    }
}

﻿namespace CompdtBEAPI.Models
{
    public class MenuObject
    {
        public string ObjectId { get; set; } = string.Empty;
        public string ObjectName { get; set; } = string.Empty;
    }
}

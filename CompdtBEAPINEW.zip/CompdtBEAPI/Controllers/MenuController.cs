﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using CompdtBEAPI.Services;

namespace CompdtBEAPI.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class MenuController : ControllerBase
    {
        private readonly IMenuService _menuService;

        public MenuController(IMenuService menuService)
        {
            _menuService = menuService;
        }

        [HttpGet("user-menu/{userId}")]
        public async Task<IActionResult> GetUserMenu(string userId)
        {
            try
            {
                var menus = await _menuService.GetUserMenuAsync(userId);
                return Ok(new { success = true, data = menus });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }
    }
}

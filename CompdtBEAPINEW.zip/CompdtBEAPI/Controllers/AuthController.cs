﻿using CompdtBEAPI.Models;

using CompdtBEAPI.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace CompdtBEAPI.Controllers
{
    [Route("api/auth-service")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;
        private readonly ILogger<AuthController> _logger;

        public AuthController(
            IAuthService authService,
            ILogger<AuthController> logger)
        {
            _authService = authService;
            _logger = logger;
        }

        [HttpPost("login")]
        [Consumes("application/json")] // Explicitly require JSON
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> Login([FromBody] LoginRequest request)
        {
            try
            {
                // Logging untuk debugging
                _logger.LogInformation("Login attempt for UserId: {UserId}", request?.UserId ?? "NULL");

                // Validasi manual jika ModelState tidak cukup
                if (request == null)
                {
                    _logger.LogWarning("Login request is null");
                    return BadRequest(new
                    {
                        success = false,
                        message = "Request body is null or invalid"
                    });
                }

                if (string.IsNullOrWhiteSpace(request.UserId))
                {
                    _logger.LogWarning("UserId is null or empty");
                    return BadRequest(new
                    {
                        success = false,
                        message = "UserId is required"
                    });
                }

                // Validate ModelState (automatic with [ApiController])
                if (!ModelState.IsValid)
                {
                    return BadRequest(new
                    {
                        success = false,
                        message = "Validation failed",
                        errors = ModelState.Values
                            .SelectMany(v => v.Errors)
                            .Select(e => e.ErrorMessage)
                    });
                }

                var result = await _authService.AuthenticateUserAsync(request.UserId);

                return Ok(new
                {
                    success = true,
                    data = result
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during login for UserId: {UserId}", request?.UserId);
                return StatusCode(500, new
                {
                    success = false,
                    message = "Internal server error",
                    detail = ex.Message
                });
            }
        }

        [HttpGet("sso-login")]
        public IActionResult SsoLogin(string returnUrl = "/")
        {
            return Challenge(new Microsoft.AspNetCore.Authentication.AuthenticationProperties
            {
                RedirectUri = returnUrl
            }, "Saml2");
        }

        [HttpPost("sso-callback")]
        public async Task<IActionResult> SsoCallback()
        {
            var authenticateResult = await HttpContext.AuthenticateAsync("Saml2");

            if (!authenticateResult.Succeeded)
            {
                return Unauthorized(new { message = "Authentication failed" });
            }

            var userId = authenticateResult.Principal.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;

            if (string.IsNullOrEmpty(userId))
            {
                return BadRequest(new { message = "User ID not found" });
            }

            var loginResponse = await _authService.AuthenticateUserAsync(userId);
            var frontendUrl = $"http://localhost:4200/auth-callback?token={loginResponse.Token}&userId={loginResponse.UserId}";

            return Redirect(frontendUrl);
        }
    }
}

﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using CompdtBEAPI.Services;
using CompdtBEAPI.Models;

namespace CompdtBEAPI.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ConsolidatePolicyController : ControllerBase
    {
        private readonly IConsolidatePolicyService _service;

        public ConsolidatePolicyController(IConsolidatePolicyService service)
        {
            _service = service;
        }

        [HttpPost("search")]
        public async Task<IActionResult> SearchPolicies([FromBody] ConsolidatePolicySearchRequest request)
        {
            try
            {
                var result = await _service.GetConsolidatePoliciesAsync(request);
                return Ok(new { success = true, data = result });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpGet("detail/{policyId}")]
        public async Task<IActionResult> GetPolicyDetail(string policyId)
        {
            try
            {
                var policyInfo = await _service.GetPolicyInfoAsync(policyId);
                var ePolicyInfo = await _service.GetEPolicyInfoAsync(policyId);
                var policySummary = await _service.GetPolicySummaryAsync(policyId);

                return Ok(new
                {
                    success = true,
                    data = new
                    {
                        policyInfo,
                        ePolicyInfo,
                        policySummary
                    }
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }
    }
}
